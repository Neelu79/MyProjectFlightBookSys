import { OriginsPipe } from './origins.pipe';

describe('OriginsPipe', () => {
  it('create an instance', () => {
    const pipe = new OriginsPipe();
    expect(pipe).toBeTruthy();
  });
});
