export class UserModel{

    Id !: number;

    Name!: string;

    Username!: string;

    Password!:string;



}