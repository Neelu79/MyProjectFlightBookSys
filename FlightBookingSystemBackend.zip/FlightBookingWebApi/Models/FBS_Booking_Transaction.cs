﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBookingWebApi.Models
{
    public class FBS_Booking_Transaction
    {
		[Key]

		public int FBS_Reference_Id { get; set; }
		//[Display(Name = "FBS_Flight_Master")]
		//[Display(Name = "FBS_Flight_Id")]

		public int FBS_Flight_Id { get; set; }

		//[ForeignKey("FBS_Flight_Id")]
		//public virtual FBS_Flight_Master fBS_Flight_Masters { get; set; }
		public string Cust_First_Name { get; set; }
		public string Cust_Last_Name { get; set; }
		public string Cust_EmailId { get; set; }
		public string Cust_Contact_No { get; set; }
	}
}
