﻿using System.Collections.Generic;
using System.Linq;
using FlightBookingWebApi.Data;
using FlightBookingWebApi.Models;
using Microsoft.AspNetCore.Mvc;


namespace FlightBookingWebApi.Controllers
{
    /// <summary>
    ///  Route for mapping using api controller attribute
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    
   //flightController class is Inherited from ControllerBase Class.

    public class FlightController : ControllerBase
    {
        /// <summary>
        /// UserDbContext class will establish connection with database here
        /// </summary>
        private readonly UserDbContext context;

        public FlightController(UserDbContext _context)
        {
            context = _context;
        }
        /// <summary>
        /// Add flight method which we use to add a flight
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        #region Add_FLight
        [HttpPost("Add_Flight")]
        public IActionResult Add_Flight([FromBody] FBS_Flight_Master obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                context.fBS_Flight_Masters.Add(obj);
                context.SaveChanges();
                return Ok(new
                {
                    Message = "Flight info add"
                });
            }
        }
        #endregion Add_FLight


        #region Get_Flight
        [HttpPost("Get_Flight")]
        public IActionResult Get_Flight([FromBody] FBS_Flight_Master obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                var user = context.fBS_Flight_Masters.Where(a =>
                a.FBS_Flight_Origin == obj.FBS_Flight_Origin
                && a.FBS_Flight_Destination == obj.FBS_Flight_Destination &&
                a.FBS_Flight_DateTime == obj.FBS_Flight_DateTime);
                return Ok(user);

            }
        }
        #endregion Get_Flight

        /// <summary>
        /// This method is used to add new passengers.
        /// </summary>
        /// <returns></returns>

       
        [HttpPost("Add_Passanger")]
        public IActionResult Add_Passanger([FromBody] FBS_Booking_Transaction obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                context.FBS_Booking_Transactions.Add(obj);
                context.SaveChanges();
                return Ok(new
                {
                    Message = "Booking successfully!!!  Your Reference no : " + obj.FBS_Reference_Id,



                    data = obj.FBS_Reference_Id
                });
            }
        }
     
        /// <summary>
        /// This method is used to get all flight details.
        /// </summary>
        /// <returns></returns>

        #region GetAllFlight
        [Route("GetAllFlight")]
        [HttpGet]
        public object GetAllFlight()
        {
            var userDetails = context.fBS_Flight_Masters.AsQueryable();
            return Ok(userDetails);
        }
         #endregion GetAllFlight

        /// <summary>
        ///  This method is used to get all passenger details.
        /// </summary>
        /// <returns></returns>
        #region GetAllPassenger
        [Route("GetAllPassenger")]
        [HttpGet]
        public object GetAllPassenger()
        {
            var userDetails = context.FBS_Booking_Transactions.AsQueryable();
            return Ok(userDetails);
        }
        #endregion GetAllPassenger

        /// <summary>
        /// GetAllDetails() method will return refernece number.
        ///  </summary>
        /// <returns></returns>

        #region GetDetails
        [Route("GetDetails")]
        [HttpGet]
        public object GetAllDetails()
        {
            var query = from p in context.fBS_Flight_Masters
                        join
                        r in context.FBS_Booking_Transactions
                        on p.FBS_Flight_Id equals r.FBS_Flight_Id
                        select new
                        {
                            ReferenceKey = r.FBS_Reference_Id,
                            flightid = p.FBS_Flight_Id,
                            first = r.Cust_First_Name,
                            last = r.Cust_Last_Name,
                            Origin = p.FBS_Flight_Origin,
                            Destination = p.FBS_Flight_Destination,
                            Time = p.FBS_Flight_DateTime
                        };


            return Ok(query);
        }
        #endregion GetDetails



    }
}
